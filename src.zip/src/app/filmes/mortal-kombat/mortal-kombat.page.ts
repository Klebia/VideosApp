import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mortal-kombat',
  templateUrl: './mortal-kombat.page.html',
  styleUrls: ['./mortal-kombat.page.scss'],
})
export class MortalKombatPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
