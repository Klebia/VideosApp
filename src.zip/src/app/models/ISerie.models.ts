export interface ISerie{
  nomeSerie: string;
  lancamentoSerie: string;
  duracaoSerie: string;
  classificacaoSerie: number;
  cartazSerie: string;
  generosSerie: string[];
  paginaSerie?: string;

}

