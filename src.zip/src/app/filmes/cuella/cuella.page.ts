import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cuella',
  templateUrl: './cuella.page.html',
  styleUrls: ['./cuella.page.scss'],
})
export class CuellaPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
