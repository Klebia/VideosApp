import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-greys',
  templateUrl: './greys.page.html',
  styleUrls: ['./greys.page.scss'],
})
export class GreysPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
