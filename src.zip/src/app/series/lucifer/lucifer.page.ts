import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lucifer',
  templateUrl: './lucifer.page.html',
  styleUrls: ['./lucifer.page.scss'],
})
export class LuciferPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
