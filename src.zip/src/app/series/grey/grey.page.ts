import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-grey',
  templateUrl: './grey.page.html',
  styleUrls: ['./grey.page.scss'],
})
export class GreyPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
